(function(){"use strict";let t=null,i=null,x=window.location.href;function g(){const e=document.createElement("style");return e.textContent=`
    #returnon-overlay {
      position: fixed;
      bottom: 28px;
      right: 28px;
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      animation: returnon-slide-in 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    @keyframes returnon-slide-in {
      from { transform: translateY(120px); opacity: 0; }
      to   { transform: translateY(0);    opacity: 1; }
    }
    @keyframes returnon-slide-out {
      from { transform: translateY(0);    opacity: 1; }
      to   { transform: translateY(120px); opacity: 0; }
    }
    #returnon-overlay.returnon-hiding {
      animation: returnon-slide-out 0.25s ease forwards;
    }
    #returnon-chat {
      background: #fff;
      border-radius: 18px 18px 4px 18px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.18), 0 2px 8px rgba(0,0,0,0.10);
      padding: 18px 20px 14px;
      max-width: 340px;
      min-width: 290px;
      border: 1.5px solid #e5e7eb;
    }
    #returnon-header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 10px;
    }
    #returnon-logo {
      width: 28px;
      height: 28px;
      background: linear-gradient(135deg, #0f766e 0%, #14b8a6 100%);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    #returnon-logo svg {
      width: 16px;
      height: 16px;
      fill: none;
      stroke: #fff;
      stroke-width: 2.2;
      stroke-linecap: round;
      stroke-linejoin: round;
    }
    #returnon-app-name {
      font-size: 12px;
      font-weight: 700;
      color: #0f766e;
      letter-spacing: 0.04em;
      text-transform: uppercase;
    }
    #returnon-message {
      font-size: 14px;
      color: #374151;
      line-height: 1.55;
      margin-bottom: 14px;
    }
    #returnon-message strong {
      color: #111827;
    }
    #returnon-actions {
      display: flex;
      flex-direction: column;
      gap: 7px;
    }
    #returnon-actions-row1 {
      display: flex;
      gap: 7px;
    }
    #returnon-return-btn {
      flex: 1;
      background: linear-gradient(135deg, #0f766e 0%, #14b8a6 100%);
      color: #fff;
      border: none;
      border-radius: 10px;
      padding: 9px 14px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      transition: opacity 0.15s, transform 0.12s;
      box-shadow: 0 2px 8px rgba(15,118,110,0.25);
    }
    #returnon-return-btn:hover {
      opacity: 0.9;
      transform: translateY(-1px);
    }
    #returnon-return-btn:active {
      transform: translateY(0);
    }
    #returnon-snooze-btn {
      background: #fff7ed;
      color: #c2410c;
      border: 1.5px solid #fed7aa;
      border-radius: 10px;
      padding: 9px 12px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.15s;
      white-space: nowrap;
    }
    #returnon-snooze-btn:hover {
      background: #ffedd5;
      color: #9a3412;
    }
    #returnon-add-btn {
      width: 100%;
      background: #f0fdf4;
      color: #15803d;
      border: 1.5px solid #bbf7d0;
      border-radius: 10px;
      padding: 8px 14px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.15s;
      text-align: center;
    }
    #returnon-add-btn:hover {
      background: #dcfce7;
      color: #166534;
    }
    #returnon-happy {
      position: fixed;
      bottom: 28px;
      right: 28px;
      z-index: 2147483647;
      background: #fff;
      border-radius: 18px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.14);
      border: 1.5px solid #e5e7eb;
      padding: 20px 28px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      animation: returnon-slide-in 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    #returnon-happy-emoji {
      font-size: 48px;
      line-height: 1;
    }
    #returnon-happy-text {
      font-size: 14px;
      font-weight: 600;
      color: #0f766e;
      text-align: center;
    }
    #returnon-added-toast {
      position: fixed;
      bottom: 28px;
      right: 28px;
      z-index: 2147483647;
      background: #f0fdf4;
      border: 1.5px solid #bbf7d0;
      border-radius: 12px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.10);
      padding: 12px 18px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 13px;
      font-weight: 600;
      color: #166534;
      animation: returnon-slide-in 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
  `,e}function u(){if(!document.getElementById("returnon-styles")){const e=g();e.id="returnon-styles",document.head.appendChild(e)}}function b(e){try{return new URL(e.startsWith("http")?e:"https://"+e).hostname.replace(/^www\./,"")}catch{return e}}function y(){if(t)return;x=window.location.href,u();const e=document.createElement("div");e.id="returnon-overlay";const n=document.createElement("div");n.id="returnon-chat";const o=document.createElement("div");o.id="returnon-header";const l=document.createElement("div");l.id="returnon-logo",l.innerHTML='<svg viewBox="0 0 24 24"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>';const m=document.createElement("span");m.id="returnon-app-name",m.textContent="Return On",o.appendChild(l),o.appendChild(m);const f=document.createElement("div");f.id="returnon-message",f.innerHTML="<strong>Gentle reminder</strong> — you seem to be deviating from your focus session. Click <strong>Return</strong> to get back on track.";const a=document.createElement("div");a.id="returnon-actions";const s=document.createElement("div");s.id="returnon-actions-row1";const r=document.createElement("button");r.id="returnon-return-btn",r.textContent="Return",r.autofocus=!0;const p=document.createElement("button");p.id="returnon-snooze-btn",p.textContent="Snooze 60s";const h=b(x),c=document.createElement("button");c.id="returnon-add-btn",c.textContent=`Add "${h}" as permissible site`,r.addEventListener("click",()=>w()),p.addEventListener("click",()=>E()),c.addEventListener("click",()=>v(h)),s.appendChild(r),s.appendChild(p),a.appendChild(s),a.appendChild(c),n.appendChild(o),n.appendChild(f),n.appendChild(a),e.appendChild(n),document.body.appendChild(e),t=e,setTimeout(()=>r.focus(),50)}function w(){d(),k(),chrome.runtime.sendMessage({type:"USER_RETURNED"})}function E(){d(),chrome.runtime.sendMessage({type:"SNOOZE"})}function v(e){d(),chrome.runtime.sendMessage({type:"ADD_PERMISSIBLE_SITE",domain:e},()=>{C(e)})}function k(){if(i)return;u();const e=document.createElement("div");e.id="returnon-happy";const n=document.createElement("div");n.id="returnon-happy-emoji",n.textContent="😊";const o=document.createElement("div");o.id="returnon-happy-text",o.textContent="Great! Back on track!",e.appendChild(n),e.appendChild(o),document.body.appendChild(e),i=e,setTimeout(()=>{i&&(i.remove(),i=null)},3e3)}function C(e){u();const n=document.createElement("div");n.id="returnon-added-toast",n.textContent=`"${e}" added as a permissible site`,document.body.appendChild(n),setTimeout(()=>n.remove(),3e3)}function d(){t&&(t.classList.add("returnon-hiding"),setTimeout(()=>{t==null||t.remove(),t=null},260))}chrome.runtime.onMessage.addListener(e=>{e.type==="SHOW_REMINDER"&&y(),e.type==="HIDE_REMINDER"&&d(),e.type==="SESSION_END"&&d()})})();
